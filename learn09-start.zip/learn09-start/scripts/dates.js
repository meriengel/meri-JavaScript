/* JavaScript Dates: https://www.w3schools.com/js/js_dates.asp */

// Create a variable, assign it to a new date object
// display the variable in the basic paragraph


// create a new date variable and load the information for today into it
// display the results in the today paragraph (Year, Month, Day)



// Create a new date variable based on the dateString and store your birthday in it
// display the variable in the birthday paragraph



// Convert your basic date to the ISO string format and display the result
// in the iso paragraph



//  Date Formats: https://www.w3schools.com/js/js_date_formats.asp
// Demonstrate 3 date formats of your choice to date1, date2, and date3 paragraphs



//  getDate() Methods: https://www.w3schools.com/js/js_date_methods.asp
// Demonstrate 4 get date methods of your choice to get1-get4 paragraphs



// set date methods: https://www.w3schools.com/js/js_date_methods_set.asp
// Demonstrate 4 set date methods of your choice to set1-set4 paragraphs